#include "TestWorld.cpp"

std::string dpath;

int main() {
	TestWorld world;
	world.start();
}